<div id="sidebar">

                <a href="#" class="logo"><img src="images/bag.png" alt=""></a>
                <ul>
                    <li class="">
                        <span><a href="user_index.php" ><i class="icon-home icon-large"></i> Home</a></span>
                    </li>
                    <li>
                        <span><a href="user_school.php"><i class=" icon-th-large icon-large"></i> Products</a></span>
                    </li>

                    <li>
                        <span><a href="user_about.php"><i class="icon-info-sign icon-large"></i> About US</a></span>
                    </li>

                    <li>
                        <span><a href="user_contact.php"><i class="icon-phone-sign icon-large"></i> Contact US</a></span>
                    </li>
					<li>
                        <span><a href="user_faq.php"><i class="icon-comment icon-large"></i> FAQ's</a></span>
                    </li>
                   

                </ul>
                <?php include('sidebar.php'); ?>
                <div class="newsletter">

                </div>
            </div>