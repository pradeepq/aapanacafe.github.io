 <div class="hero-unit-table">
							
		<a href = "school.php" name = "" class = "btn btn-success">School</a> 
		<a href = "travelling.php" name = "" class = "btn btn-primary">Travelling</a> 			
		<a href = "Hand.php" name = "" class = "btn btn-info">Hand Bag</a> 

						
</div>