 <div class="contact">
                        <ul>
                            <li class="address">
                                <span>Address</span>
                                <ul>
                                    <li>
									<i class = "icon icon-home"></i>
									<p>CHMSC </p>
									<p>Talisay City ,Negros Occidental</p>
                                    </li>
                                  
                                
                                </ul>
                            </li>
                            <li class="contactInfo">
								
									<i class = "icon icon-user"></i>
                                <ul>
                                    <li>
                                        +123xxxxxxxx
                                    </li>
                                    <li>
                                        +745xxxxxxxx
                                    </li>
                                </ul>
                            </li>
                            <li class="mail">
                                <i class = "icon icon-envelope"> </i>
                                <ul>
                                    <li>
                                        <a href="#">asdfghj@gmail.com</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                   