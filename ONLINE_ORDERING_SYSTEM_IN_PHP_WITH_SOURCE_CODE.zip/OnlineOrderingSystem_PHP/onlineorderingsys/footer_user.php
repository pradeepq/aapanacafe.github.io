<ul>
    <li>
        <a href="user_index.php"><i class="icon-home"></i>Home</a>
    </li>
    <li>
        <a href="user_guitar.php"><i class=" icon-th-large"></i>Products</a>
    </li>

    <li>
        <a href="user_about.php"><i class="icon-info-sign"></i>About US</a>
    </li>
    <li>
        <a href="user_contact.php"><i class="icon-phone-sign"></i>Contact US</a>
    </li>
  

</ul>
<p>
     <a href="">&copy; Surf N' Shop All Rights Reserved.</a> 
</p>


